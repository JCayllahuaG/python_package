from .test_class import HelloWorld

hello = HelloWorld()

__all__ = ['hello']