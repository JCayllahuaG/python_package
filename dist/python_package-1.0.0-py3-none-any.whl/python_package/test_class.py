class HelloWorld:
    def say_hello(self):
        return "Hello World"